import os
import shutil
import threading
import re
from pathlib import Path
from PySide6.QtCore import QObject, Signal
from audio_analyzer import AudioAnalyzer

class UniversalWorker(QObject):
    progress = Signal(int)
    log = Signal(str)
    finished = Signal()

    def __init__(self, source, dest, mode="all", **kwargs):
        super().__init__()
        self.source = Path(source); self.dest = Path(dest)
        self.mode = mode # media, visual, project
        self.pref = kwargs.get('pref', 'persian')
        self._stop = threading.Event()

    def _normalize(self, n):
        return n.lower().replace(" ", "").replace("_", "").replace("-", "").replace("ي", "ی").replace("ك", "ک")

    def _find_smart_folder(self, parent, target, is_artist=False):
        if not parent.exists(): return target
        t_norm = self._normalize(target)
        variants = AudioAnalyzer.get_all_variants(target) if is_artist else [target]
        v_norms = [self._normalize(v) for v in variants]
        try:
            for entry in os.scandir(parent):
                if entry.is_dir() and (self._normalize(entry.name) == t_norm or self._normalize(entry.name) in v_norms):
                    if is_artist and entry.name != target and self.pref == "persian":
                        try: os.rename(entry.path, parent / target); return target
                        except: return entry.name
                    return entry.name
        except: pass
        return target

    def _get_path_info(self, path):
        ext = path.suffix.lower(); name = path.stem.lower()
        
        # 1. MEDIA LOGIC
        if ext in {'.mp3', '.wav', '.flac', '.m4a'}:
            meta = AudioAnalyzer.analyze(path)
            pref_a = AudioAnalyzer.get_preferred_name(meta["artist"], self.pref) or "سایر_آهنگ‌ها"
            root = ["موسیقی_و_صوت", pref_a]
            if meta["album"]: root.append(meta["album"])
            return root, AudioAnalyzer.destination_filename(path, meta, self.pref)

        # 2. VISUAL/DESIGN LOGIC
        if ext in {'.psd', '.cdr', '.ai', '.eps', '.svg', '.jpg', '.png'}:
            if ext == ".psd": p = ["تصاویر", "لایه_باز", "Photoshop"]
            elif ext == ".cdr": p = ["گرافیک_وکتور", "CorelDRAW"]
            elif ext in {'.ai', '.eps', '.svg'}: p = ["گرافیک_وکتور", "Vector_Assets"]
            else: p = ["تصاویر", "سایر_عکس‌ها"]
            return p, path.name

        return ["سایر_موارد"], path.name

    def run(self):
        try:
            files = [p for p in self.source.rglob("*") if p.is_file()]
            total = len(files)
            for i, path in enumerate(files):
                if self._stop.is_set(): break
                parts, new_name = self._get_path_info(path)
                
                # SMART SYNC FOLDER NAVIGATION
                curr = self.dest
                for j, p in enumerate(parts):
                    is_art = (j == 1 and parts[0] == "موسیقی_و_صوت")
                    folder = self._find_smart_folder(curr, p, is_artist=is_art)
                    curr = curr / folder
                
                curr.mkdir(parents=True, exist_ok=True)
                dest_file = curr / new_name
                if dest_file.exists(): dest_file = curr / f"{Path(new_name).stem}_کپی{Path(new_name).suffix}"
                
                shutil.copy2(path, dest_file)
                self.log.emit(f"بایگانی در {curr.name}: {new_name}")
                self.progress.emit(int((i+1)*100/max(total,1)))
        finally: self.finished.emit()

    def stop(self): self._stop.set()
