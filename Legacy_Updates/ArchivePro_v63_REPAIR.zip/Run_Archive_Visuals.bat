@echo off
title "ArchivePro - Visuals Edition"
echo Starting Specialized Visuals Tool...
python visual_main.py
pause
