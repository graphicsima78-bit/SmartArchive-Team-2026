@echo off
title "ArchivePro - Audio & Video Edition"
echo Starting Specialized Audio Tool...
python media_main.py
pause
