@echo off
title "ArchivePro - Audio & Video MASTER"
echo Starting Professional Media Archive Engine...
python media_main.py
pause
