@echo off
title "ArchivePro - Visual Master"
cd /d "%~dp0"
echo Starting Specialized Design & Image Tool...
python visual_main.py
pause
