@echo off
title "ArchivePro - Audio & Video MASTER"
cd /d "%~dp0"
echo Starting Professional Media Archive Engine...
python media_main.py
pause
